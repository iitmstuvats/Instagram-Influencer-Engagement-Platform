from flask import render_template, redirect, url_for, request, flash
from flask import current_app as app
from flask_login import login_user, logout_user, current_user, login_required
from sqlalchemy.exc import OperationalError
from time import sleep
import os
from .models import db, User, Sponsor, Influencer, Campaign, AdRequest
from .forms import InfluencerRegistrationForm, SponsorRegistrationForm, LoginForm, CampaignForm, SearchInfluencersForm, \
    AdRequestForm, InfluencerProfileForm, SearchCompanyForm
import base64


# General Routes



@app.route('/')
def index():
    return render_template('index.html')


@app.route('/signup_select')
def signup_select():
    return render_template('signup_select.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    user_type = request.args.get('type')
    if user_type == 'influencer':
        return redirect(url_for('signup_influencer'))
    elif user_type == 'sponsor':
        return redirect(url_for('signup_sponsor'))
    else:
        return redirect(url_for('signup_select'))


# influencer routes

@app.route('/signup/influencer', methods=['GET', 'POST'])
def signup_influencer():
    form = InfluencerRegistrationForm()

    # Update niche choices based on selected category
    valid_niches = {
        'Fashion': ['Streetwear', 'Haute Couture', 'Casual'],
        'Technology': ['Gadgets', 'Software', 'AI'],
        'Food': ['Recipes', 'Restaurant Reviews', 'Healthy Eating'],
        'Travel': ['Adventure', 'Luxury', 'Budget']
    }

    if form.category.data in valid_niches:
        form.niche.choices = [(niche, niche) for niche in valid_niches[form.category.data]]
    else:
        form.niche.choices = []

    if form.validate_on_submit():
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user is None:
            # Process the profile picture
            picture_data = None
            if form.picture.data:
                picture_data = form.picture.data.read()

            # Create the new user with the picture
            user = User(username=form.username.data, role='influencer', picture=picture_data)
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()

            # Create the influencer profile
            influencer = Influencer(user_id=user.id, name=form.name.data, category=form.category.data,
                                    niche=form.niche.data, reach=form.reach.data)
            db.session.add(influencer)
            db.session.commit()

            flash('Influencer account created successfully!', 'success')
            return redirect(url_for('login'))  # Redirect to login page after signup
        else:
            flash('Username already exists. Please choose a different username.', 'danger')
    return render_template('signup_influencer.html', form=form)


# Path to the file where influencer complaints will be stored
INFLUENCER_COMPLAINT_FILE = 'influencer_complaints.txt'


def read_complaints_for_influencer(influencer_name):
    complaints = []
    if os.path.exists(INFLUENCER_COMPLAINT_FILE):
        with open(INFLUENCER_COMPLAINT_FILE, 'r') as file:
            content = file.read().strip()
            entries = content.split('\n\n')  # Split different complaints
            for entry in entries:
                parts = entry.split('\n')
                if len(parts) == 5 and parts[0].split(": ")[
                    1].strip() == influencer_name:  # Ensure all lines are present
                    complaints.append({
                        'influencer': parts[0].split(": ")[1].strip(),
                        'campaign': parts[1].split(": ")[1].strip(),
                        'sponsor': parts[2].split(": ")[1].strip(),
                        'message': parts[3].split(": ")[1].strip(),
                        'status': parts[4].split(": ")[1].strip()
                    })
    return complaints


@app.route('/influencer_page')
@login_required
def influencer_page():
    if current_user.role != 'influencer':
        return redirect(url_for('index'))

    influencer = Influencer.query.filter_by(user_id=current_user.id).first()
    ad_requests = AdRequest.query.filter_by(influencer_id=influencer.id).all()
    form = SearchCompanyForm()  # Ensure the form is created here
    complaints = read_complaints_for_influencer(current_user.username)

    picture_data = None
    if influencer.user.picture:
        # Ensure the picture is correctly encoded
        picture_data = base64.b64encode(influencer.user.picture).decode('utf-8')

    return render_template('influencer_page.html', influencer=influencer, ad_requests=ad_requests, form=form,
                           complaints=complaints, picture_data=picture_data)


def commit_with_retry(session, max_retries=5, delay=1):
    retries = 0
    while retries < max_retries:
        try:
            session.commit()
            return
        except OperationalError as e:
            if 'database is locked' in str(e):
                session.rollback()  # Rollback the session to clear the failed transaction
                retries += 1
                sleep(delay)
            else:
                raise
    raise Exception('Max retries exceeded for committing to the database')


@app.route('/accept_ad_request/<int:ad_request_id>', methods=['POST'])
@login_required
def accept_ad_request(ad_request_id):
    ad_request = AdRequest.query.get_or_404(ad_request_id)
    if ad_request.influencer_id != current_user.influencer.id:
        return redirect(url_for('influencer_page'))
    ad_request.status = 'Accepted'
    try:
        commit_with_retry(db.session)
        flash('Ad request accepted.', 'success')
    except Exception as e:
        flash(f'Failed to accept ad request: {e}', 'danger')
    return redirect(url_for('ad_request_by_sponsor'))


@app.route('/reject_ad_request/<int:ad_request_id>', methods=['POST'])
@login_required
def reject_ad_request(ad_request_id):
    ad_request = AdRequest.query.get_or_404(ad_request_id)
    if ad_request.influencer_id != current_user.influencer.id:
        return redirect(url_for('influencer_page'))
    ad_request.status = 'Rejected'
    try:
        commit_with_retry(db.session)
        flash('Ad request rejected.', 'danger')
    except Exception as e:
        flash(f'Failed to reject ad request: {e}', 'danger')
    return redirect(url_for('ad_request_by_sponsor'))


@app.route('/modify_ad_request/<int:ad_request_id>', methods=['GET', 'POST'])
@login_required
def modify_ad_request(ad_request_id):
    if current_user.role != 'influencer':
        return redirect(url_for('index'))

    ad_request = AdRequest.query.get_or_404(ad_request_id)

    if request.method == 'POST':
        message = request.form.get('message')
        ad_request.messages = message
        ad_request.status = 'Pending'
        db.session.commit()
        flash('Modification request sent successfully!', 'success')
        return redirect(url_for('ad_request_by_sponsor'))

    return render_template('modify_ad_request.html', ad_request=ad_request)


@app.route('/update_profile', methods=['GET', 'POST'])
@login_required
def update_profile():
    if current_user.role != 'influencer':
        return redirect(url_for('index'))
    influencer = Influencer.query.filter_by(user_id=current_user.id).first()
    form = InfluencerProfileForm(obj=influencer)
    if form.validate_on_submit():
        form.populate_obj(influencer)
        db.session.commit()
        flash('Profile updated successfully.', 'success')
        return redirect(url_for('influencer_page'))
    return render_template('update_profile.html', form=form)


@app.route('/search_campaigns', methods=['POST'])
@login_required
def search_campaigns():
    if current_user.role != 'influencer':
        return redirect(url_for('index'))

    form = SearchCompanyForm()  # Create the form object
    search_query = form.search_query.data  # Use form data
    search_type = form.search_type.data  # Use form data

    if form.validate_on_submit():  # Validate the form on submit
        if search_type == 'company':
            # Join Campaigns with Sponsors to search for company name
            campaigns = Campaign.query.join(Sponsor).filter(
                Sponsor.company_name.ilike(f'%{search_query}%'),
                Campaign.visibility == 'Public'
            ).all()
        elif search_type == 'industry':
            # Join Campaigns with Sponsors to search for industry
            campaigns = Campaign.query.join(Sponsor).filter(
                Sponsor.industry.ilike(f'%{search_query}%'),
                Campaign.visibility == 'Public'
            ).all()
        else:
            campaigns = []

        return render_template('view_public_campaign.html', campaigns=campaigns)

    return redirect(url_for('influencer_page'))


@app.route('/ad_request_by_sponsor')
@login_required
def ad_request_by_sponsor():
    if current_user.role != 'influencer':
        return redirect(url_for('index'))

    influencer = Influencer.query.filter_by(user_id=current_user.id).first()

    # Get all ad requests by the influencer
    pending_requests = AdRequest.query.filter(
        AdRequest.influencer_id == influencer.id,
        AdRequest.status == 'Pending',
        AdRequest.messages == None
    ).all()
    accepted_requests = AdRequest.query.filter(
        AdRequest.influencer_id == influencer.id,
        AdRequest.status == 'Accepted',
        (AdRequest.messages == None) | AdRequest.messages.contains("Sponsor is agree and request is accepted")
    ).all()
    rejected_requests = AdRequest.query.filter(
        AdRequest.influencer_id == influencer.id,
        AdRequest.status == 'Rejected',
        (AdRequest.messages == None) | AdRequest.messages.contains("Sponsor is not agree and request is rejected")
    ).all()
    modify_requests = AdRequest.query.filter(
        AdRequest.influencer_id == influencer.id,
        AdRequest.messages != None,
        ~AdRequest.messages.contains("Application by influencer"),
    ).all()

    return render_template('ad_request_by_sponsor.html',
                           pending_requests=pending_requests,
                           accepted_requests=accepted_requests,
                           rejected_requests=rejected_requests,
                           modify_requests=modify_requests)


@app.route('/apply_to_campaign/<int:campaign_id>', methods=['POST'])
@login_required
def apply_to_campaign(campaign_id):
    if current_user.role != 'influencer':
        return redirect(url_for('index'))

    # Retrieve the message from the form
    message = request.form.get('message')

    # Check if message is None and set a default value if it is
    if message is None:
        message = ""

    ad_request = AdRequest(
        campaign_id=campaign_id,
        influencer_id=current_user.influencer.id,
        requirements='',
        payment_amount=0,
        status='Pending',
        messages="Application by influencer: " + message
    )
    db.session.add(ad_request)
    db.session.commit()

    flash('Applied to campaign successfully!', 'success')
    return redirect(url_for('influencer_page'))


@app.route('/ad_request_by_influencer_to_sponsor')
@login_required
def ad_request_by_influencer_to_sponsor():
    if current_user.role != 'influencer':
        return redirect(url_for('index'))

    influencer = Influencer.query.filter_by(user_id=current_user.id).first()

    pending_requests = AdRequest.query.filter(
        AdRequest.influencer_id == influencer.id,
        AdRequest.status == 'Pending',
        AdRequest.messages.contains("Application by influencer")
    ).all()
    accepted_requests = AdRequest.query.filter(
        AdRequest.influencer_id == influencer.id,
        AdRequest.status == 'Accepted',
        AdRequest.messages.contains("Application by influencer")
    ).all()
    rejected_requests = AdRequest.query.filter(
        AdRequest.influencer_id == influencer.id,
        AdRequest.status == 'Rejected',
        AdRequest.messages.contains("Application by influencer")
    ).all()

    return render_template('ad_request_by_influencer_to_sponsor.html',
                           pending_requests=pending_requests,
                           accepted_requests=accepted_requests,
                           rejected_requests=rejected_requests)


@app.route('/delete_ad_request_by_influencer/<int:ad_request_id>', methods=['POST'])
@login_required
def delete_ad_request_by_influencer(ad_request_id):
    if current_user.role != 'influencer':
        return redirect(url_for('index'))
    ad_request = AdRequest.query.get_or_404(ad_request_id)
    if ad_request.influencer_id != current_user.influencer.id:
        return redirect(url_for('ad_request_by_influencer_to_sponsor'))
    db.session.delete(ad_request)
    db.session.commit()
    flash('Ad request deleted successfully!', 'success')
    return redirect(url_for('ad_request_by_influencer_to_sponsor'))


# Modify ad request by influencer
@app.route('/modify_ad_request_by_influencer/<int:ad_request_id>', methods=['POST'])
@login_required
def modify_ad_request_by_influencer(ad_request_id):
    if current_user.role != 'influencer':
        return redirect(url_for('index'))

    ad_request = AdRequest.query.get_or_404(ad_request_id)

    if request.method == 'POST':
        ad_request.messages = request.form['message']
        ad_request.status = 'Pending'
        db.session.commit()
        flash('Ad request modified successfully!', 'success')

    return redirect(url_for('ad_request_by_influencer_to_sponsor'))


# Sponsor Routes



@app.route('/signup/sponsor', methods=['GET', 'POST'])
def signup_sponsor():
    form = SponsorRegistrationForm()
    if form.validate_on_submit():
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user is None:
            user = User(username=form.username.data, role='sponsor')
            user.set_password(form.password.data)

            # Handle picture upload
            if form.picture.data:
                picture_data = form.picture.data.read()
                user.picture = picture_data

            db.session.add(user)
            db.session.commit()

            sponsor = Sponsor(user_id=user.id, company_name=form.company_name.data, industry=form.industry.data,
                              budget=form.budget.data)
            db.session.add(sponsor)
            db.session.commit()
            flash('Sponsor account created successfully!', 'success')
            return redirect(url_for('login'))  # Redirect to login page after signup
        else:
            flash('Username already exists. Please choose a different username.', 'danger')
    return render_template('signup_sponsor.html', form=form)


# Path to the file where complaints will be stored
COMPLAINT_FILE = 'sponsor_complaints.txt'


def read_complaints_for_sponsor(sponsor_name):
    complaints = []
    with open(COMPLAINT_FILE, 'r') as file:
        for line in file:
            if line.startswith('Sponsor:'):
                current_complaint = {}
                current_complaint['sponsor'] = line.split(': ')[1].strip()
                if current_complaint['sponsor'] == sponsor_name:
                    current_complaint['influencer'] = file.readline().split(': ')[1].strip()
                    current_complaint['message'] = file.readline().split(': ')[1].strip()
                    current_complaint['status'] = file.readline().split(': ')[1].strip()
                    complaints.append(current_complaint)
    return complaints


@app.route('/sponsor_page')
@login_required
def sponsor_page():
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))

    sponsor = Sponsor.query.filter_by(user_id=current_user.id).first()
    user = User.query.get(current_user.id)  # Fetch the user data
    picture_data = None

    if user.picture:
        picture_data = base64.b64encode(user.picture).decode('utf-8')  # Encode image to base64

    influencers = []
    form = SearchInfluencersForm()
    complaints = read_complaints_for_sponsor(current_user.username)

    return render_template('sponsor_page.html', sponsor=sponsor, influencers=influencers, form=form,
                           complaints=complaints, picture_data=picture_data)


@app.route('/view_all_campaigns')
@login_required
def view_all_campaigns():
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))
    sponsor = Sponsor.query.filter_by(user_id=current_user.id).first()
    campaigns = Campaign.query.filter_by(sponsor_id=sponsor.id).all()
    form = SearchInfluencersForm()
    return render_template('view_all_campaigns.html', sponsor=sponsor, campaigns=campaigns, form=form)


@app.route('/view_campaign/<int:campaign_id>', methods=['GET'])
@login_required
def view_campaign(campaign_id):
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))
    campaign = Campaign.query.get_or_404(campaign_id)
    return render_template('view_campaign.html', campaign=campaign)


@app.route('/view_influencer/<int:influencer_id>', methods=['GET'])
@login_required
def view_influencer(influencer_id):
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))
    influencer = Influencer.query.get_or_404(influencer_id)
    return render_template('view_influencer.html', influencer=influencer)


@app.route('/send_ad_request/<int:influencer_id>', methods=['GET', 'POST'])
@login_required
def send_ad_request(influencer_id):
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))

    form = AdRequestForm()
    influencer = Influencer.query.get_or_404(influencer_id)

    if form.validate_on_submit():
        campaign_name = form.campaign_name.data
        campaign = Campaign.query.filter_by(name=campaign_name, sponsor_id=current_user.sponsor.id).first()

        if campaign:
            ad_request = AdRequest(
                campaign_id=campaign.id,
                influencer_id=influencer.id,
                requirements=form.requirements.data,
                payment_amount=form.payment_amount.data,
                status='Pending'
            )
            db.session.add(ad_request)
            try:
                commit_with_retry(db.session)
                flash('Ad request sent successfully!', 'success')
                return redirect(url_for('sponsor_page'))
            except Exception as e:
                flash(f'Failed to send ad request: {e}', 'danger')
        else:
            flash('Campaign not found. Please check the campaign name and try again.', 'danger')

    return render_template('send_ad_request.html', form=form, influencer=influencer)


@app.route('/ad_request_to_influencer')
@login_required
def ad_request_to_influencer():
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))

    sponsor = Sponsor.query.filter_by(user_id=current_user.id).first()

    # Get all campaigns by the sponsor
    campaigns = Campaign.query.filter_by(sponsor_id=sponsor.id).all()
    campaign_ids = [campaign.id for campaign in campaigns]

    # Filter ad requests by campaign ids and ensure messages column is empty
    accepted_requests = AdRequest.query.filter(AdRequest.campaign_id.in_(campaign_ids),
                                               AdRequest.status == 'Accepted',
                                               (AdRequest.messages == None) | AdRequest.messages.contains(
                                                   "Sponsor is agree and request is accepted")).all()

    pending_requests = AdRequest.query.filter(AdRequest.campaign_id.in_(campaign_ids),
                                              AdRequest.status == 'Pending',
                                              AdRequest.messages == None).all()

    rejected_requests = AdRequest.query.filter(AdRequest.campaign_id.in_(campaign_ids),
                                               AdRequest.status == 'Rejected',
                                               (AdRequest.messages == None) | AdRequest.messages.contains(
                                                   "Sponsor is not agree and request is rejected")).all()

    modify_requests = AdRequest.query.filter(AdRequest.campaign_id.in_(campaign_ids),
                                             AdRequest.status == 'Pending',
                                             ~AdRequest.messages.contains("Application by influencer"),
                                             AdRequest.messages != None).all()

    return render_template('ad_request_to_influencer.html', accepted_requests=accepted_requests,
                           pending_requests=pending_requests, rejected_requests=rejected_requests,
                           modify_requests=modify_requests)


@app.route('/create_campaign', methods=['GET', 'POST'])
@login_required
def create_campaign():
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))

    form = CampaignForm()
    if form.validate_on_submit():
        campaign = Campaign(
            sponsor_id=current_user.sponsor.id,
            name=form.name.data,
            description=form.description.data,
            start_date=form.start_date.data,
            end_date=form.end_date.data,
            budget=form.budget.data,
            visibility=form.visibility.data,
            goals=form.goals.data
        )
        db.session.add(campaign)
        db.session.commit()
        flash('Campaign created successfully!', 'success')
        return redirect(url_for('sponsor_page'))
    else:
        print(form.errors)  # Print form errors to the console for debugging

    return render_template('create_campaign.html', form=form, title="Create Campaign")


@app.route('/update_campaign/<int:campaign_id>', methods=['GET', 'POST'])
@login_required
def update_campaign(campaign_id):
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))
    campaign = Campaign.query.get_or_404(campaign_id)
    form = CampaignForm(obj=campaign)
    if form.validate_on_submit():
        campaign.name = form.name.data
        campaign.description = form.description.data
        campaign.start_date = form.start_date.data
        campaign.end_date = form.end_date.data
        campaign.budget = form.budget.data
        campaign.visibility = form.visibility.data
        campaign.goals = form.goals.data
        db.session.commit()
        flash('Campaign updated successfully!', 'success')
        return redirect(url_for('sponsor_page'))
    return render_template('create_campaign.html', form=form, title="Update Campaign")


@app.route('/delete_campaign/<int:campaign_id>', methods=['POST'])
@login_required
def delete_campaign(campaign_id):
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))
    campaign = Campaign.query.get_or_404(campaign_id)
    db.session.delete(campaign)
    db.session.commit()
    flash('Campaign deleted successfully!', 'success')
    return redirect(url_for('sponsor_page'))


@app.route('/search_influencers', methods=['POST'])
@login_required
def search_influencers():
    search_query = request.form.get('search_query')
    search_type = request.form.get('search_type')
    form = AdRequestForm()  # Ensure the form is created here

    if search_query and search_type:
        if search_type == 'username':
            influencers = db.session.query(Influencer).join(User).filter(
                User.username.ilike(f'%{search_query}%')
            ).all()
        elif search_type == 'influencer_name':
            influencers = Influencer.query.filter(
                Influencer.name.ilike(f'%{search_query}%')
            ).all()
        elif search_type == 'category':
            influencers = Influencer.query.filter(
                Influencer.category.ilike(f'%{search_query}%')
            ).all()
        elif search_type == 'niche':
            influencers = Influencer.query.filter(
                Influencer.niche.ilike(f'%{search_query}%')
            ).all()
        elif search_type == 'reach':
            try:
                reach_value = int(search_query)
                influencers = Influencer.query.filter(
                    Influencer.reach >= reach_value
                ).all()
            except ValueError:
                flash('Invalid reach value. Please enter a numeric value.', 'danger')
                return redirect(url_for('sponsor_page'))
        else:
            influencers = []

        if influencers:
            return render_template('view_influencer.html', influencers=influencers, form=form)
        else:
            flash('No influencers found with that search query.', 'danger')
            return redirect(url_for('sponsor_page'))
    return redirect(url_for('sponsor_page'))


# Delete ad request
@app.route('/delete_ad_request/<int:ad_request_id>', methods=['POST'])
@login_required
def delete_ad_request(ad_request_id):
    ad_request = AdRequest.query.get_or_404(ad_request_id)
    if current_user.role != 'sponsor' or ad_request.campaign.sponsor_id != current_user.sponsor.id:
        return redirect(url_for('index'))
    db.session.delete(ad_request)
    db.session.commit()
    flash('Ad request deleted successfully!', 'success')
    return redirect(url_for('ad_request_to_influencer'))


# Modify ad request by sponsor
@app.route('/modify_ad_request_by_sponsor/<int:ad_request_id>', methods=['GET', 'POST'])
@login_required
def modify_ad_request_by_sponsor(ad_request_id):
    ad_request = AdRequest.query.get_or_404(ad_request_id)
    if current_user.role != 'sponsor' or ad_request.campaign.sponsor_id != current_user.sponsor.id:
        return redirect(url_for('index'))

    form = AdRequestForm()

    # Get all campaigns for the logged-in sponsor
    sponsor = Sponsor.query.filter_by(user_id=current_user.id).first()
    campaigns = Campaign.query.filter_by(sponsor_id=sponsor.id).all()

    if request.method == 'GET':
        form = AdRequestForm(obj=ad_request)
        form.campaign_name.data = ad_request.campaign.name  # Pre-fill the campaign name

    if form.validate_on_submit():
        # Find the new campaign by name
        new_campaign = Campaign.query.filter_by(name=form.campaign_name.data,
                                                sponsor_id=current_user.sponsor.id).first()
        if new_campaign:
            ad_request.campaign_id = new_campaign.id
        else:
            flash('Campaign not found. Please check the campaign name and try again.', 'danger')
            return redirect(url_for('modify_ad_request_by_sponsor', ad_request_id=ad_request_id))

        ad_request.requirements = form.requirements.data
        ad_request.payment_amount = form.payment_amount.data

        db.session.commit()
        flash('Ad request updated successfully!', 'success')
        return redirect(url_for('ad_request_to_influencer'))

    return render_template('modify_ad_request_by_sponsor.html', form=form, ad_request=ad_request, campaigns=campaigns)


@app.route('/agree_update_request/<int:ad_request_id>', methods=['POST'])
@login_required
def agree_update_request(ad_request_id):
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))
    ad_request = AdRequest.query.get_or_404(ad_request_id)
    if ad_request.campaign.sponsor_id != current_user.sponsor.id:
        return redirect(url_for('ad_request_to_influencer'))

    ad_request.messages = "Sponsor is agree and request is accepted"
    ad_request.status = 'Accepted'
    db.session.commit()
    flash('Ad request updated and accepted.', 'success')
    return redirect(url_for('ad_request_to_influencer'))


@app.route('/not_agree_update_request/<int:ad_request_id>', methods=['POST'])
@login_required
def not_agree_update_request(ad_request_id):
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))
    ad_request = AdRequest.query.get_or_404(ad_request_id)
    if ad_request.campaign.sponsor_id != current_user.sponsor.id:
        return redirect(url_for('ad_request_to_influencer'))

    ad_request.messages = "Sponsor is not agree and request is rejected"
    ad_request.status = 'Rejected'
    db.session.commit()
    flash('Ad request rejected.', 'danger')
    return redirect(url_for('ad_request_to_influencer'))


@app.route('/modify_ad_request_by_sponsor_on_influencer_demand/<int:ad_request_id>', methods=['GET', 'POST'])
@login_required
def modify_ad_request_by_sponsor_on_influencer_demand(ad_request_id):
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))

    ad_request = AdRequest.query.get_or_404(ad_request_id)
    if ad_request.campaign.sponsor_id != current_user.sponsor.id:
        return redirect(url_for('ad_request_to_influencer'))

    if request.method == 'POST':
        ad_request.requirements = request.form['requirements']
        ad_request.payment_amount = request.form['payment_amount']
        ad_request.messages = "Sponsor has updated the request"
        db.session.commit()
        flash('Ad request updated.', 'success')
        return redirect(url_for('ad_request_to_influencer'))

    return render_template('modify_ad_request_by_sponsor_on_influencer_demand.html', ad_request=ad_request)


@app.route('/influencer_send_you_request_for_campaign')
@login_required
def influencer_send_you_request_for_campaign():
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))

    sponsor = Sponsor.query.filter_by(user_id=current_user.id).first()
    campaign_ids = [campaign.id for campaign in sponsor.campaigns]

    accepted_requests = AdRequest.query.filter(AdRequest.campaign_id.in_(campaign_ids),
                                               AdRequest.messages.contains("Application by influencer"),
                                               AdRequest.status == 'Accepted').all()

    rejected_requests = AdRequest.query.filter(AdRequest.campaign_id.in_(campaign_ids),
                                               AdRequest.messages.contains("Application by influencer"),
                                               AdRequest.status == 'Rejected').all()

    pending_requests = AdRequest.query.filter(AdRequest.campaign_id.in_(campaign_ids),
                                              AdRequest.messages.contains("Application by influencer"),
                                              AdRequest.status == 'Pending').all()

    return render_template('influencer_send_you_request_for_campaign.html',
                           accepted_requests=accepted_requests,
                           rejected_requests=rejected_requests,
                           pending_requests=pending_requests)


@app.route('/accept_request/<int:request_id>', methods=['POST'])
@login_required
def accept_request(request_id):
    ad_request = AdRequest.query.get_or_404(request_id)
    ad_request.status = 'Accepted'
    db.session.commit()
    flash('Request accepted successfully!', 'success')
    return redirect(url_for('influencer_send_you_request_for_campaign'))


@app.route('/reject_request/<int:request_id>', methods=['POST'])
@login_required
def reject_request(request_id):
    ad_request = AdRequest.query.get_or_404(request_id)
    ad_request.status = 'Rejected'
    db.session.commit()
    flash('Request rejected successfully!', 'success')
    return redirect(url_for('influencer_send_you_request_for_campaign'))


@app.route('/update_request/<int:request_id>', methods=['POST'])
@login_required
def update_request(request_id):
    ad_request = AdRequest.query.get_or_404(request_id)
    ad_request.requirements = request.form['requirements']
    ad_request.payment_amount = request.form['payment_amount']
    db.session.commit()
    flash('Request updated successfully!', 'success')
    return redirect(url_for('influencer_send_you_request_for_campaign'))



# General Routes



@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user:
            if user.flagged:
                flash('Your account has been flagged by the admin. Please contact the admin for further assistance.',
                      'danger')
                return redirect(url_for('login'))  # Redirect back to the login page
            elif user.check_password(form.password.data):
                login_user(user, remember=form.remember_me.data)
                if user.role == 'sponsor':
                    return redirect(url_for('sponsor_page'))
                elif user.role == 'influencer':
                    return redirect(url_for('influencer_page'))
                elif user.role == 'admin':
                    return redirect(url_for('admin_page'))  # Redirect to admin page
                else:
                    return redirect(url_for('index'))
        flash('Invalid username or password', 'danger')
    return render_template('login.html', form=form)


@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))


# admin routes

# Path to the directory where sponsor complaints will be stored
COMPLAINT_FILE = 'sponsor_complaints.txt'


@app.route('/admin_page')
@login_required
def admin_page():
    if current_user.role != 'admin':
        return redirect(url_for('index'))

    sponsors = Sponsor.query.all()
    influencers = Influencer.query.all()
    complaints = read_complaints()
    campaign_complaints = read_campaign_complaints()
    return render_template('admin_page.html', sponsors=sponsors, influencers=influencers, complaints=complaints,
                           campaign_complaints=campaign_complaints)


@app.route('/report_influencer/<int:influencer_id>', methods=['POST'])
@login_required
def report_influencer(influencer_id):
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))

    influencer = Influencer.query.get_or_404(influencer_id)
    complaint_message = request.form.get('complaint_message')

    if not complaint_message:
        flash('Complaint message is required.', 'danger')
        return redirect(url_for('view_influencer', influencer_id=influencer_id))

    sponsor_name = current_user.username
    influencer_name = influencer.name

    # Write the complaint to the file
    with open(COMPLAINT_FILE, 'a') as file:
        file.write(f"Sponsor: {sponsor_name}\n")
        file.write(f"Influencer: {influencer_name}\n")
        file.write(f"Message: {complaint_message}\n")
        file.write(f"Status: Pending\n")
        file.write("\n")  # Separate entries

    flash('Complaint submitted successfully.', 'success')
    return redirect(url_for('view_influencer', influencer_id=influencer_id))


@app.route('/update_complaint_status/<int:complaint_index>/<string:status>', methods=['POST'])
@login_required
def update_complaint_status(complaint_index, status):
    if current_user.role != 'admin':
        return redirect(url_for('index'))

    complaints = read_complaints()
    if 0 <= complaint_index < len(complaints):
        complaints[complaint_index]['status'] = status
        write_complaints(complaints)
        flash(f'Complaint status updated to {status}.', 'success')
    else:
        flash('Invalid complaint index.', 'danger')

    return redirect(url_for('admin_page'))


def read_complaints():
    complaints = []
    if os.path.exists(COMPLAINT_FILE):
        with open(COMPLAINT_FILE, 'r') as file:
            content = file.read().strip()
            entries = content.split('\n\n')  # Split different complaints
            for entry in entries:
                parts = entry.split('\n')
                if len(parts) == 4:  # Ensure all lines are present
                    complaints.append({
                        'sponsor': parts[0].split(": ")[1].strip(),
                        'influencer': parts[1].split(": ")[1].strip(),
                        'message': parts[2].split(": ")[1].strip(),
                        'status': parts[3].split(": ")[1].strip()
                    })
    return complaints


def write_complaints(complaints):
    with open(COMPLAINT_FILE, 'w') as file:
        for complaint in complaints:
            file.write(f"Sponsor: {complaint['sponsor']}\n")
            file.write(f"Influencer: {complaint['influencer']}\n")
            file.write(f"Message: {complaint['message']}\n")
            file.write(f"Status: {complaint['status']}\n")
            file.write("\n")  # Separate entries


# Path to the file where influencer complaints will be stored
CAMPAIGN_COMPLAINT_FILE = 'influencer_complaints.txt'


@app.route('/report_campaign/<int:campaign_id>', methods=['POST'])
@login_required
def report_campaign(campaign_id):
    if current_user.role != 'influencer':
        return redirect(url_for('index'))

    campaign = Campaign.query.get_or_404(campaign_id)
    complaint_message = request.form.get('complaint_message')

    if not complaint_message:
        flash('Complaint message is required.', 'danger')
        return redirect(url_for('public_campaigns'))

    influencer_name = current_user.username
    campaign_name = campaign.name
    sponsor_name = campaign.sponsor.company_name

    # Write the complaint to the file
    with open(CAMPAIGN_COMPLAINT_FILE, 'a') as file:
        file.write(f"Influencer: {influencer_name}\n")
        file.write(f"Campaign: {campaign_name}\n")
        file.write(f"Sponsor: {sponsor_name}\n")
        file.write(f"Message: {complaint_message}\n")
        file.write(f"Status: Pending\n")
        file.write("\n")  # Separate entries

    flash('Complaint submitted successfully.', 'success')
    return redirect(url_for('influencer_page'))


def read_campaign_complaints():
    complaints = []
    if os.path.exists(CAMPAIGN_COMPLAINT_FILE):
        with open(CAMPAIGN_COMPLAINT_FILE, 'r') as file:
            content = file.read().strip()
            entries = content.split('\n\n')  # Split different complaints
            for entry in entries:
                parts = entry.split('\n')
                if len(parts) == 5:  # Ensure all lines are present
                    complaints.append({
                        'influencer': parts[0].split(": ")[1].strip(),
                        'campaign': parts[1].split(": ")[1].strip(),
                        'sponsor': parts[2].split(": ")[1].strip(),
                        'message': parts[3].split(": ")[1].strip(),
                        'status': parts[4].split(": ")[1].strip()
                    })
    return complaints


def write_campaign_complaints(complaints):
    with open(CAMPAIGN_COMPLAINT_FILE, 'w') as file:
        for complaint in complaints:
            file.write(f"Influencer: {complaint['influencer']}\n")
            file.write(f"Campaign: {complaint['campaign']}\n")
            file.write(f"Sponsor: {complaint['sponsor']}\n")
            file.write(f"Message: {complaint['message']}\n")
            file.write(f"Status: {complaint['status']}\n")
            file.write("\n")  # Separate entries


@app.route('/update_campaign_complaint_status/<int:complaint_index>/<string:status>', methods=['POST'])
@login_required
def update_campaign_complaint_status(complaint_index, status):
    if current_user.role != 'admin':
        return redirect(url_for('index'))

    campaign_complaints = read_campaign_complaints()
    if 0 <= complaint_index < len(campaign_complaints):
        campaign_complaints[complaint_index]['status'] = status
        write_campaign_complaints(campaign_complaints)
        flash(f'Campaign complaint status updated to {status}.', 'success')
    else:
        flash('Invalid complaint index.', 'danger')

    return redirect(url_for('admin_page'))


# Add the route to flag and unflag users

@app.route('/flag_user/<int:user_id>/<string:action>', methods=['POST'])
@login_required
def flag_user(user_id, action):
    if current_user.role != 'admin':
        return redirect(url_for('index'))

    user = User.query.get_or_404(user_id)
    if action == 'flag':
        user.flagged = True
        flash(f'User {user.username} has been flagged.', 'success')
    elif action == 'unflag':
        user.flagged = False
        flash(f'User {user.username} has been unflagged.', 'success')
    else:
        flash('Invalid action.', 'danger')

    db.session.commit()
    return redirect(url_for('admin_page'))


# admin_dashboard


@app.route('/admin_dashboard')
@login_required
def admin_dashboard():
    if current_user.role != 'admin':
        return redirect(url_for('index'))

    # Fetch the required data from the database
    total_users = User.query.count()
    total_sponsors = Sponsor.query.count()
    total_influencers = Influencer.query.count()
    total_campaigns = Campaign.query.count()
    total_budget = db.session.query(db.func.sum(Campaign.budget)).scalar()

    public_campaigns = Campaign.query.filter_by(visibility='Public').count()
    private_campaigns = Campaign.query.filter_by(visibility='Private').count()

    sponsors = Sponsor.query.all()
    sponsors_names = [sponsor.company_name for sponsor in sponsors]
    campaigns_per_sponsor = [len(sponsor.campaigns) for sponsor in sponsors]

    categories = ['Fashion', 'Technology', 'Food', 'Travel']

    campaigns_per_category = [
        db.session.query(db.func.count(Campaign.id)).join(Sponsor).filter(
            Campaign.sponsor_id == Sponsor.id,
            Sponsor.industry.contains(category)
        ).scalar()
        for category in categories
    ]

    flagged_sponsors = User.query.join(Sponsor).filter(User.flagged == True).count()
    flagged_influencers = User.query.join(Influencer).filter(User.flagged == True).count()

    campaigns = Campaign.query.all()
    campaigns_names = [campaign.name for campaign in campaigns]
    campaigns_budgets = [campaign.budget for campaign in campaigns]

    return render_template('admin_dashboard.html',
                           total_users=total_users,
                           total_sponsors=total_sponsors,
                           total_influencers=total_influencers,
                           total_campaigns=total_campaigns,
                           total_budget=total_budget,
                           public_campaigns=public_campaigns,
                           private_campaigns=private_campaigns,
                           sponsors_names=sponsors_names,
                           campaigns_per_sponsor=campaigns_per_sponsor,
                           campaigns_per_category=campaigns_per_category,
                           flagged_sponsors=flagged_sponsors,
                           flagged_influencers=flagged_influencers,
                           campaigns_names=campaigns_names,
                           campaigns_budgets=campaigns_budgets)


# sponsor dashboard


@app.route('/sponsor_dashboard')
@login_required
def sponsor_dashboard():
    if current_user.role != 'sponsor':
        return redirect(url_for('index'))

    sponsor = Sponsor.query.filter_by(user_id=current_user.id).first()

    # Fetch data for the charts
    campaigns = Campaign.query.filter_by(sponsor_id=sponsor.id).all()
    campaigns_names = [campaign.name for campaign in campaigns]
    campaigns_budgets = [campaign.budget for campaign in campaigns]

    influencers_per_campaign = [len(campaign.ad_requests) for campaign in campaigns]

    categories = ['Fashion', 'Technology', 'Food', 'Travel']
    influencers_by_category = [
        db.session.query(Influencer).join(AdRequest).join(Campaign).filter(
            Campaign.visibility == 'Public',
            Influencer.category == category,
            Campaign.sponsor_id == sponsor.id
        ).count() for category in categories
    ]

    complaints = read_complaints_for_sponsor(current_user.username)
    resolved_complaints = sum(1 for complaint in complaints if complaint['status'] == 'Resolved')
    pending_complaints = sum(1 for complaint in complaints if complaint['status'] == 'Pending')
    rejected_complaints = sum(1 for complaint in complaints if complaint['status'] == 'Rejected')

    complaints_entities = [complaint['influencer'] or complaint['campaign'] for complaint in complaints]
    complaints_per_entity = [complaints_entities.count(entity) for entity in set(complaints_entities)]

    return render_template('sponsor_dashboard.html',
                           campaigns_names=campaigns_names,
                           campaigns_budgets=campaigns_budgets,
                           influencers_per_campaign=influencers_per_campaign,
                           influencers_by_category=influencers_by_category,
                           resolved_complaints=resolved_complaints,
                           pending_complaints=pending_complaints,
                           rejected_complaints=rejected_complaints,
                           complaints_entities=list(set(complaints_entities)),
                           complaints_per_entity=complaints_per_entity)


# influencer_dashboard

@app.route('/influencer_dashboard')
@login_required
def influencer_dashboard():
    if current_user.role != 'influencer':
        return redirect(url_for('index'))

    influencer = Influencer.query.filter_by(user_id=current_user.id).first()

    # Data for Distribution of Ad Requests by Status
    ad_requests_status = db.session.query(
        AdRequest.status, db.func.count(AdRequest.id)
    ).filter_by(influencer_id=influencer.id).group_by(AdRequest.status).all()

    ad_requests_status_labels = [status for status, count in ad_requests_status]
    ad_requests_status_counts = [count for status, count in ad_requests_status]

    # Data for Number of Ad Requests per Campaign
    ad_requests_per_campaign = db.session.query(
        Campaign.name, db.func.count(AdRequest.id)
    ).join(AdRequest).filter(AdRequest.influencer_id == influencer.id).group_by(Campaign.name).all()

    campaigns_names = [campaign for campaign, count in ad_requests_per_campaign]
    ad_requests_counts = [count for campaign, count in ad_requests_per_campaign]

    # Data for Complaints by Status
    complaints = read_complaints_for_influencer(influencer.user.username)
    resolved_complaints = sum(1 for complaint in complaints if complaint['status'] == 'Resolved')
    pending_complaints = sum(1 for complaint in complaints if complaint['status'] == 'Pending')
    rejected_complaints = sum(1 for complaint in complaints if complaint['status'] == 'Rejected')

    # Data for Earnings from Different Campaigns
    earnings_per_campaign = db.session.query(
        Campaign.name, db.func.sum(AdRequest.payment_amount)
    ).join(AdRequest).filter(AdRequest.influencer_id == influencer.id, AdRequest.status == 'Accepted').group_by(
        Campaign.name).all()

    earnings_campaign_names = [campaign for campaign, earnings in earnings_per_campaign]
    earnings_campaign_amounts = [earnings for campaign, earnings in earnings_per_campaign]

    # Data for Earnings Comparison Between Private and Public Campaigns
    public_earnings = db.session.query(db.func.sum(AdRequest.payment_amount)).join(Campaign).filter(
        AdRequest.influencer_id == influencer.id, Campaign.visibility == 'Public', AdRequest.status == 'Accepted'
    ).scalar() or 0

    private_earnings = db.session.query(db.func.sum(AdRequest.payment_amount)).join(Campaign).filter(
        AdRequest.influencer_id == influencer.id, Campaign.visibility == 'Private', AdRequest.status == 'Accepted'
    ).scalar() or 0

    return render_template('influencer_dashboard.html',
                           ad_requests_status_labels=ad_requests_status_labels,
                           ad_requests_status_counts=ad_requests_status_counts,
                           campaigns_names=campaigns_names,
                           ad_requests_counts=ad_requests_counts,
                           resolved_complaints=resolved_complaints,
                           pending_complaints=pending_complaints,
                           rejected_complaints=rejected_complaints,
                           earnings_campaign_names=earnings_campaign_names,
                           earnings_campaign_amounts=earnings_campaign_amounts,
                           public_earnings=public_earnings,
                           private_earnings=private_earnings)
