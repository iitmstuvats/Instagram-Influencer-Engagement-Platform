from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, IntegerField, TextAreaField, FloatField, \
    DateField, SelectField, FileField
from wtforms.validators import DataRequired, Length, Regexp, ValidationError
from app.models import User
from flask_wtf.file import FileAllowed, FileRequired


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(),
        Length(min=2, max=50),
        Regexp('^[A-Za-z][A-Za-z0-9_]*$', 0, 'Usernames must have only letters, numbers, or underscores')
    ])
    password = PasswordField('Password', validators=[DataRequired(),
                                                     Length(min=6, max=20)
                                                     ])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Login')


class InfluencerRegistrationForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(),
        Length(min=2, max=50),
        Regexp('^[A-Za-z][A-Za-z0-9_]*$', 0, 'Usernames must have only letters, numbers, or underscores')
    ])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=6, max=20)
    ])
    name = StringField('Full Name', validators=[
        DataRequired(),
        Length(min=2, max=50),
        Regexp('^[A-Za-z ]*$', 0, 'Full Name must have only letters and spaces')
    ])
    category = SelectField('Category', choices=[
        ('Fashion', 'Fashion'),
        ('Technology', 'Technology'),
        ('Food', 'Food'),
        ('Travel', 'Travel')
    ], validators=[DataRequired()])
    niche = SelectField('Niche', choices=[], validators=[DataRequired()])
    reach = StringField('Reach', validators=[
        DataRequired(),
        Regexp('^[0-9]+$', 0, 'Reach must be a valid number')
    ])
    picture = FileField('Profile Picture', validators=[FileAllowed(['jpg', 'png']), FileRequired()])
    submit = SubmitField('Sign Up')


    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already exists. Please choose a different username.')

    def validate_niche(form, field):
        valid_niches = {
            'Fashion': ['Streetwear', 'Haute Couture', 'Casual'],
            'Technology': ['Gadgets', 'Software', 'AI'],
            'Food': ['Recipes', 'Restaurant Reviews', 'Healthy Eating'],
            'Travel': ['Adventure', 'Luxury', 'Budget']
        }
        if field.data not in valid_niches.get(form.category.data, []):
            raise ValidationError('Not a valid choice.')


class SponsorRegistrationForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(),
        Length(min=2, max=50),
        Regexp('^[A-Za-z][A-Za-z0-9_]*$', 0, 'Usernames must have only letters, numbers, or underscores')
    ])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=6, max=20)
    ])
    company_name = StringField('Company Name', validators=[
        DataRequired(),
        Length(min=2, max=50),
        Regexp('^[A-Za-z ]*$', 0, 'Company Name must have only letters and spaces')
    ])
    industry = SelectField('Industry', choices=[('Fashion', 'Fashion'), ('Technology', 'Technology'), ('Food', 'Food'), ('Travel', 'Travel')], validators=[DataRequired()])
    budget = StringField('Budget', validators=[
        DataRequired(),
        Regexp('^[0-9]+$', 0, 'Budget must be a valid number')
    ])
    picture = FileField('Profile Picture', validators=[FileAllowed(['jpg', 'png'])])
    submit = SubmitField('Sign Up')


    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already exists. Please choose a different username.')



class CampaignForm(FlaskForm):
    name = StringField('Campaign Name', validators=[DataRequired(), Length(min=1, max=100)])
    description = TextAreaField('Description', validators=[DataRequired()])
    start_date = DateField('Start Date', validators=[DataRequired()], format='%Y-%m-%d')
    end_date = DateField('End Date', validators=[DataRequired()], format='%Y-%m-%d')
    budget = FloatField('Budget', validators=[DataRequired()])
    visibility = SelectField('Visibility', choices=[('Public', 'Public'), ('Private', 'Private')],
                             validators=[DataRequired()])
    goals = TextAreaField('Goals', validators=[DataRequired()])


class SearchInfluencersForm(FlaskForm):
    search_query = StringField('Search Influencers', validators=[DataRequired()])
    submit = SubmitField('Search')


class AdRequestForm(FlaskForm):
    campaign_name = StringField('Campaign Name', validators=[DataRequired()])
    requirements = TextAreaField('Requirements', validators=[DataRequired()])
    payment_amount = FloatField('Payment Amount', validators=[DataRequired()])
    submit = SubmitField('Send Request')


class InfluencerProfileForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    category = StringField('Category', validators=[DataRequired()])
    niche = StringField('Niche', validators=[DataRequired()])
    reach = IntegerField('Reach', validators=[DataRequired()])
    submit = SubmitField('Update Profile')


class SearchCompanyForm(FlaskForm):
    search_query = StringField('Search by Company Name', validators=[DataRequired()])
    search_type = SelectField('Search Type', choices=[('company', 'Company Name'), ('industry', 'Industry')], validators=[DataRequired()])
    submit = SubmitField('Search')



class ModifyAdRequestForm(FlaskForm):
    messages = TextAreaField('Modification Message', validators=[DataRequired()])
    submit = SubmitField('Submit')
