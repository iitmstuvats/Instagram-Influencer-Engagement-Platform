import sqlite3


def create_tables():
    connection = sqlite3.connect('app.db')
    cursor = connection.cursor()

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password_hash VARCHAR(100) NOT NULL,
        role VARCHAR(20) NOT NULL
        flagged BOOLEAN NOT NULL DEFAULT 0
        picture BLOB
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS sponsors (
        id INTEGER PRIMARY KEY,
        user_id INTEGER NOT NULL,
        company_name VARCHAR(100) NOT NULL,
        industry VARCHAR(50) NOT NULL,
        budget FLOAT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS influencers (
        id INTEGER PRIMARY KEY,
        user_id INTEGER NOT NULL,
        name VARCHAR(100) NOT NULL,
        category VARCHAR(50) NOT NULL,
        niche VARCHAR(50) NOT NULL,
        reach INTEGER NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS campaigns (
        id INTEGER PRIMARY KEY,
        sponsor_id INTEGER NOT NULL,
        name VARCHAR(100) NOT NULL,
        description TEXT NOT NULL,
        start_date DATETIME NOT NULL,
        end_date DATETIME NOT NULL,
        budget FLOAT NOT NULL,
        visibility VARCHAR(20) NOT NULL,
        goals TEXT NOT NULL,
        FOREIGN KEY(sponsor_id) REFERENCES sponsors(id)
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS ad_requests (
        id INTEGER PRIMARY KEY,
        campaign_id INTEGER NOT NULL,
        influencer_id INTEGER NOT NULL,
        messages TEXT,
        requirements TEXT NOT NULL,
        payment_amount FLOAT NOT NULL,
        status VARCHAR(20) NOT NULL,
        FOREIGN KEY(campaign_id) REFERENCES campaigns(id),
        FOREIGN KEY(influencer_id) REFERENCES influencers(id)
    )
    ''')

    connection.commit()
    connection.close()


if __name__ == '__main__':
    create_tables()
    print("Database initialized and tables created.")
